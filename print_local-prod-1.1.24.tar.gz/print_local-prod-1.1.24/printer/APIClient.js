var request = require('request');
const logger = require('./logger');

  const fetchFromAPI_JSON = async (url, data) => {
    return new Promise((resolve, reject) => {
      request(
        {
          method: "POST",
          url,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        },
        (error, response) => {
          if (error) {
            logger.logError(error);
            return reject(error);
          }
          try {
            resolve(JSON.parse(response.body));
          } catch (e) {
            reject("Invalid JSON response");
          }
        }
      );
    });
  };

  const fetchFromAPI_Raw = async (url, data) => {
    return new Promise((resolve, reject) => {
      request(
        {
          method: "POST",
          url,
          headers: { "Content-Type": "application/json" },
          body: data,
        },
        (error, response) => {
          if (error) {
            logger.logError(error);
            return reject(error);
          }
          try {
            resolve(response.body);
          } catch (e) {
            reject("Invalid JSON response");
          }
        }
      );
    });
  };

async function docman_createDoc(data) {
  return await fetchFromAPI_JSON(`${process.env.DocmanService}/api/V1/create-doc`,data);
}

async function pdf_genPdf(data) {
  return await fetchFromAPI_JSON(`${process.env.PDFGenerateService}/gen-pdf`,data);
}

async function ovSmartPrint_htmlTemplate(data) {
  return await fetchFromAPI_Raw(`${process.env.OVSmartPrintService}/v1/htmltemplate`,data);
}

module.exports = {
  docman_createDoc,
  pdf_genPdf,
  ovSmartPrint_htmlTemplate
}
