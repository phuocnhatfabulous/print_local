TIMEOUT 1
call npm stop