
var CryptoJS = require("crypto-js");
var request = require('request');
var jwtdecode = require('jwt-decode');
const path = require("path");
const fs = require('fs');
const logger = require('./logger');
const download = require('./download.js');
const APIClient = require('./APIClient.js');

const PrintOptionsLinuxDefault = "media=Custom.5.82x8.26in";
// const PrintOptionsLinux ={
//   "A4_landscape" : "media=Custom.11.69x8.27in",
//   "A4_portrait" : "media=Custom.8.27x11.69in",
//   "A5_landscape" : "media=Custom.8.26x5.82in",
//   "A5_portrait" : "media=Custom.5.82x8.26in",
//   "A6_landscape" : "media=Custom.5.8x4.1in",
//   "A6_portrait" : "media=Custom.4.1x5.8in",
//   "A7_landscape" : "media=Custom.4.1x2.9in",
//   "A7_portrait" : "media=Custom.2.9x4.0in",
// };
const ScaleOptionsLinux = {
  "noscale": "print-scaling=none position=top-left",
  "fit": "fit-to-page",
  "shrink": "scaling=60",
};

function makeid(length) {
  return Array.from({ length }, () =>
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".charAt(
      Math.floor(Math.random() * 62)
    )
  ).join("");
}

function makeStorePath() {
  const d = new Date();
  return `eton/wms/ops/${d.getFullYear()}/${(d.getMonth() + 1).toString().padStart(2, "0")}`;
}

async function convertBas64ToPDF(base64, optionsInput, fileName) {
  var param = {
    "content": base64,
    "type": "fullhtml",
    "encode": "base64",
    "print_option": {
      "printBackground": true,
      "format": optionsInput.pageSize || 'A4',
      "page_name": fileName,
      "scale": optionsInput.scale || optionsInput.zoom || 1,
      "margin": {
        "bottom": optionsInput.marginBottom || '0mm',
        "left": optionsInput.marginLeft || '10mm',
        "right": optionsInput.marginRight || '10mm',
        "top": optionsInput.marginTop || '10mm',
      }
    },
    "extra_info": {
      "store_path": makeStorePath()
    }

  };
  if (optionsInput.footerRight) {
    param['print_option']['displayHeaderFooter'] = true;
    param['print_option']['footerTemplate'] = `
        <div style="font-size: 10px; padding-top: 5px;padding-right: 20px; text-align: right; width: 100%;">
          <span class="pageNumber"></span>/<span class="totalPages"></span>
        </div>`

  }
  return await APIClient.pdf_genPdf(param);
}

async function convertURLToPDFByPdfService(url, format, fileName) {
  var param = {
    "content": url,
    "type": "url",
    "encode": "base64",
    "print_option": {
      "printBackground": true,
      "page_name": fileName,
      ...
      format
    },
    "extra_info": {
      "store_path": makeStorePath()
    }
  };
  var response = APIClient.pdf_genPdf(param);
  return response;
}

async function getTemplateOVSmartPrint(data) {
  var param = CryptoJS.enc.Utf8.stringify(CryptoJS.enc.Base64.parse(data));
  var response = await APIClient.ovSmartPrint_htmlTemplate(param);
  var result = jwtdecode(response);
  return result;
}

const getTemplateDocman = async (wmsData, convertMethod, extendParam, fileName) => {
  const convertedWMSData = JSON.parse(CryptoJS.enc.Utf8.stringify(CryptoJS.enc.Base64.parse(wmsData)));
  // const preFix = convertedWMSData.template || ''; 
  const data = {
    templateCode: convertedWMSData.template,
    fileType: convertMethod,
    printing: false,
    file_store_path: makeStorePath(),
    file_name: fileName,
    data: convertedWMSData.data,
    ...extendParam
  };
  const docmanRes = await APIClient.docman_createDoc(data);
  return {
    data: docmanRes.data,
    options: convertedWMSData.printTemplateMapping?.PrintOptions,
    name: convertedWMSData.template,
    fileName
  };
}

async function generatePDFFileFromData({ data, fileName }) {

  let template = await getTemplateOVSmartPrint(data);
  // var preFix = template.name || template.type || ''; 
  // var fileName = `${preFix}_${makeid(8)}_${(new Date().getTime())/1}`;
  template.content = template.content.replace(/[%]pwd[%]/ig, process.env.OVSmartPrintService);
  template.content = template.content.replace(/[%]host[%]/ig, process.env.OVSmartPrintService);
  var base64 = Buffer.from(template.content).toString('base64');
  let result = await convertBas64ToPDF(base64, template.options, fileName);
  if (result.success != true || !result.url) {
    logger.logError("generatePDFFileFromData Lỗi API convert Base64 To PDF:" + fileName);
    return {
      fileUrl: '',
      options: null
    }
  }

  var config = readFilePrinterConfig();
  if (config && config["PrioritySettings"] && config["PrioritySettings"][template.name]) {
    template.options.orientation = config["PrioritySettings"][template.name].Orientation,
      template.options.scale = config["PrioritySettings"][template.name].Scale
  }

  return {
    fileUrl: result.url,
    options: {
      "Orientation": template.options.orientation || "portrait",
      "Paper": template.options.pageSize || 'A5',
      "Scale": template.options.scale || "noscale"
    }
  }
}

async function generatePDFFileFromDataByPrintLocal({ data, fileName }) {
  let template = await getTemplateOVSmartPrint(data);
  // var preFix = template.name || template.type || ''; 
  // var fileName = `${preFix}_${makeid(8)}_${(new Date().getTime())/1}`;
  template.content = template.content.replace(/[%]pwd[%]/ig, process.env.OVSmartPrintService);
  template.content = template.content.replace(/[%]host[%]/ig, process.env.OVSmartPrintService);
  // var _format ={};
  // var config = readFilePrinterConfig();
  // if(config && config['PageSize']){
  //   _format = config['PageSize'][template.options.pageSize];
  // }

  // var param = {
  //   "print_option": {
  //       "scale" : template.options.scale || template.options.zoom || 1,
  //       "margin":{
  //         "bottom": template.options.marginBottom || '0mm',
  //         "left": template.options.marginLeft || '10mm',
  //         "right": template.options.marginRight || '10mm',
  //         "top": template.options.marginTop || '10mm',
  //       },...
  //       _format
  //   }
  // };

  // if(template.options.footerRight){
  //   param['print_option']['displayHeaderFooter'] = true;
  //   param['print_option']['footerTemplate'] = `
  //   <div style="font-size: 10px; padding-top: 5px;padding-right: 20px; text-align: right; width: 100%;">
  //     <span class="pageNumber"></span>/<span class="totalPages"></span>
  //   </div>`

  // }
  var param = formatcrawEncodedHTMLOptions(template.options);
  const result = await download.crawEncodedHTML(template.content, param.print_option, fileName)
  if (result.success != true || !result.url) {
    logger.logError("generatePDFFileFromDataByPrintLocal Lỗi API convert Base64 To PDF:" + fileName);
    return {
      fileUrl: "",
      options: null
    }
  }

  var config = readFilePrinterConfig();
  if (config && config["PrioritySettings"] && config["PrioritySettings"][template.name]) {
    template.options.orientation = config["PrioritySettings"][template.name].Orientation,
      template.options.scale = config["PrioritySettings"][template.name].Scale
  }

  return {
    fileUrl: result.url,
    options: {
      "Orientation": template.options.orientation || "portrait",
      "Paper": template.options.pageSize || 'A5',
      "Scale": template.options.scale || "noscale"
    }
  }
}

const generatePDFFileFromPDFUrl = async ({ data, filename }) => {
  const template = await getTemplateDocman(data, 'pdf', {}, filename);

  var config = readFilePrinterConfig();
  if (config && config["PrioritySettings"] && config["PrioritySettings"][template.name]) {
    template.options.orientation = config["PrioritySettings"][template.name].Orientation,
      template.options.scale = config["PrioritySettings"][template.name].Scale
  }

  return {
    fileUrl: template.data.pdfUrl,
    options: {
      "Orientation": template.options.orientation || "portrait",
      "Paper": template.options.pageSize || 'A5',
      "Scale": template.options.scale || "noscale"
    }
  }
}

const generatePDFFileFromHtmlUrl = async ({ data, filename }) => {
  const template = await getTemplateDocman(data, 'html', { useLocalDocMgmtUrlOnly: true, includeHtmlContentBase64: true }, filename);
  var _fileUrl = template.data.htmlUrl;
  if (template.data.htmlContentBase64) {
    const decodedBuffer = Buffer.from(template.data.htmlContentBase64, 'base64').toString('utf-8');
    var param = formatcrawEncodedHTMLOptions(template.options);
    const result = await download.crawEncodedHTML(decodedBuffer, param.print_option, filename)
    if (result.success != true || !result.url) {
      logger.logError("generatePDFFileFromHtmlUrl Lỗi API convert Base64 To PDF:" + filename);
      return {
        fileUrl: "",
        options: null
      }
    }
    _fileUrl = result.url;
  }

  var config = readFilePrinterConfig();
  if (config && config["PrioritySettings"] && config["PrioritySettings"][template.name]) {
    template.options.orientation = config["PrioritySettings"][template.name].Orientation,
      template.options.scale = config["PrioritySettings"][template.name].Scale
  }
  return {
    // fileUrl : template.data.htmlUrl,
    fileUrl: _fileUrl,
    options: {
      "Orientation": template.options?.orientation || "portrait",
      "Paper": template.options?.pageSize || 'A5',
      "Scale": template.options?.scale || "noscale"
    }
  }
}

async function generatePDFFileFromURL(url, optionsInput) {
  var fileName = "";
  var extname = path.extname(url);
  if (extname == ".html") {
    fileName = (path.basename(url, ".html") + `_${makeid(8)}`).trim().replace(/%20/g, " ");
  } else if (extname == ".pdf") {
    fileName = (path.basename(url, ".pdf") + `_${makeid(8)}`).trim().replace(/%20/g, " ");
  }
  var _format = { format: 'A6' };
  if (optionsInput && optionsInput['Paper']) {
    var config = readFilePrinterConfig();
    if (config && config['PageSize']) {
      _format = config['PageSize'][optionsInput['Paper']];
    }
  }

  if (optionsInput && (optionsInput['margin'] || optionsInput['Margin'])) {
    _format['margin'] = optionsInput['margin'] || optionsInput['Margin'];
  }

  let result = await convertURLToPDFByPdfService(url, _format, fileName);
  if (result.success != true || !result.url) {
    logger.logError("Lỗi API convert HTML or PDF To PDF:" + fileName);
    return {
      fileUrl: '',
      options: {}
    }
    // throw new Error("Lỗi API convert HTML or PDF To PDF");
  }
  return {
    fileUrl: result.url.trim().replace(/ /g, "%20"),
    options: {}
  }
}

function formatcrawEncodedHTMLOptions(options) {
  var _format = {};
  var config = readFilePrinterConfig();
  if (config && config['PageSize']) {
    _format = config['PageSize'][options.pageSize];
  }
  var param = {
    "print_option": {
      "scale": options.scale || options.zoom || 1,
      "margin": {
        "bottom": options.marginBottom || '0mm',
        "left": options.marginLeft || '10mm',
        "right": options.marginRight || '10mm',
        "top": options.marginTop || '10mm',
      }, ...
      _format
    }
  };

  if (options.footerRight) {
    param['print_option']['displayHeaderFooter'] = true;
    param['print_option']['footerTemplate'] = `
    <div style="font-size: 10px; padding-top: 5px;padding-right: 20px; text-align: right; width: 100%;">
      <span class="pageNumber"></span>/<span class="totalPages"></span>
    </div>`

  }
  return param;
}


function formatWindowsPrintSettings(options) {
  var setting = "";
  if (options) {
    var isHasPrintOptionsWindows = false;
    var config = readFilePrinterConfig();
    if (config && config['PrintOptionsWindows']) {
      if (config['PrintOptionsWindows'][`${options['Paper']}_${options['Orientation'].toLowerCase()}`]) {
        setting = config['PrintOptionsWindows'][`${options['Paper']}_${options['Orientation'].toLowerCase()}`];
        isHasPrintOptionsWindows = true;
      }
    }
    
    if(!isHasPrintOptionsWindows)
    {
      if (options['Orientation']) {
        setting = options['Orientation'];
      }
      else {
        setting = "portrait";
      }

      if (options['Paper']) {
        setting = setting + ",Paper=" + options['Paper']
      }
      else {
        setting = setting + ",Paper=A6"
      }
    }
    

    if (options['Scale']) {
      setting = setting + "," + options['Scale']
    }

    if (options['Color']) {
      setting = setting + "," + options['Color']
    }

    if (options['Copies']) {
      setting = setting + "," + options['Copies'] + 'x'
    }


   
  }
  return setting;
}

function formatLinuxPrintSettings(options) {
  var setting = "";
  if (options) {
    if (options['Paper'] && options['Orientation']) {
      setting = PrintOptionsLinuxDefault; // default A5_portrait
      var config = readFilePrinterConfig();
      if (config && config['PrintOptionsLinux']) {
        if (config['PrintOptionsLinux'][`${options['Paper']}_${options['Orientation'].toLowerCase()}`]) {
          setting = config['PrintOptionsLinux'][`${options['Paper']}_${options['Orientation'].toLowerCase()}`];
        }
      }
    }
    if (options['Scale']) {
      if (ScaleOptionsLinux[options['Scale']]) {
        setting = setting + " " + ScaleOptionsLinux[options['Scale']]
      }
    }
  }
  return setting;
}

function getDefaultPrinter(printerpaper) {
  var printername = "";
  var config = readFilePrinterConfig();
  if (config && config['PrinterName']) {
    printername = config['PrinterName'][printerpaper];
  }
  return printername;
}

const readFilePrinterConfig = () => {
  try {
    const data = fs.readFileSync('./PrinterConfig.txt', 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error(err);
    return null;
  }
}
module.exports = {
  generatePDFFileFromData,
  generatePDFFileFromURL,
  generatePDFFileFromDataByPrintLocal,
  generatePDFFileFromPDFUrl,
  generatePDFFileFromHtmlUrl,
  readFilePrinterConfig,
  makeid,
  formatWindowsPrintSettings,
  formatLinuxPrintSettings,
  getDefaultPrinter
}
