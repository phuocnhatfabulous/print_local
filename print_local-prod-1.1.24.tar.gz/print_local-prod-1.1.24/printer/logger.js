var fs = require('fs');
var logDir = './logs';
if (!fs.existsSync(logDir)){
  fs.mkdirSync(logDir);
  
}

function makePath() {
  var d = new Date(),
      month = '' + (d.getMonth() + 1),
      year = d.getFullYear();
      day = '' + d.getDate();
  if (month.length < 2) 
      month = '0' + month;
  if (day.length < 2) 
    day = '0' + day;
  return `${[year, month, day].join('-')}.log`
}

CreateFileLog = function ()
{
  var path =  makePath();
  var log_file = fs.createWriteStream(`${logDir}/${path}`, {flags : 'a'});
  return log_file;
}

log = function(message) {
  CreateFileLog().write(formatInput(message) + '\n');
};

logError = function(message) {
  CreateFileLog().write(formatInput(message , 'ERROR') + '\n');
};

logInfo = function(message) {
  CreateFileLog().write(formatInput(message, 'INFO') + '\n');
};

formatInput = function(message, type) {
  return `${new Date()}: ${type || ''} ${message}`;
}

module.exports = {
  log,
  logError,
  logInfo,
}