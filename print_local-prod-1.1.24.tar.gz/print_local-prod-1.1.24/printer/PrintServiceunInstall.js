const Config = require("./config");
const service = require('node-windows').Service
Config.loadDefault();
var name = process.env.ServiceName || 'PrintLocal';  
var svc = new service({
  name:name,
  description: 'Print Service',
  script: './index.js'
});

svc.on('uninstall',function(){
  console.log('This service is already uninstalled.');
});

svc.uninstall();
