@echo off

echo Setting up environment.
echo.

set NULL_VAL=null
set NODE_VER=%NULL_VAL%
set REQUIRED_VER=v23.9.0
set NODE_EXEC=node-v23.9.0-x86.msi

echo Checking Node.js has been installed yet.
echo.
node -v >.tmp_nodever 2>nul
set /p NODE_VER=<.tmp_nodever
del .tmp_nodever

rem Kiểm tra nếu Node.js chưa được cài đặt
IF "%NODE_VER%"=="%NULL_VAL%" (
    echo Node.js is not installed! Please press a key to download and install it from the website that will open.
    echo.
    PAUSE
    start "" https://nodejs.org/en/blog/release/v23.9.0
    echo After you have installed Node.js, press a key to shut down this process. Please restart it again afterwards.
    echo.
    PAUSE
    EXIT
)

echo A version of Node.js ^(%NODE_VER%^) is installed.
echo.

rem So sánh phiên bản hiện tại với phiên bản yêu cầu
for /f "tokens=1 delims=v" %%a in ("%NODE_VER%") do set NODE_VER=%%a
for /f "tokens=1 delims=v" %%b in ("%REQUIRED_VER%") do set REQUIRED_VER=%%b

call :version_compare %NODE_VER% %REQUIRED_VER%
if %ERRORLEVEL%==1 (
    echo Installed version is older than required. Downloading the latest version.
    echo.
    start "" https://nodejs.org/en/blog/release/v23.9.0
    echo Please install the new version and restart the script.
    echo.
    PAUSE
    EXIT
)

echo Trying to start Sprinter application.
echo.

echo Opening application location: "%~dp0"
echo.

cd %~dp0

node index.js

exit

:version_compare
setlocal
set v1=%1
set v2=%2
for /f "tokens=1,2,3 delims=." %%a in ("%v1%") do set "major1=%%a" & set "minor1=%%b" & set "patch1=%%c"
for /f "tokens=1,2,3 delims=." %%a in ("%v2%") do set "major2=%%a" & set "minor2=%%b" & set "patch2=%%c"

if %major1% LSS %major2% exit /b 1
if %major1% GTR %major2% exit /b 0

if %minor1% LSS %minor2% exit /b 1
if %minor1% GTR %minor2% exit /b 0

if %patch1% LSS %patch2% exit /b 1
if %patch1% GTR %patch2% exit /b 0

exit /b 0
