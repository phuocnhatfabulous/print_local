const puppeteer = require('puppeteer');
const fs = require('fs');
const chromeLauncher = require('chrome-launcher');
// /**
//  * @type {Browser}
//  */
// // var myBrowser

const getChromePath = () => {
    let chromePath = chromeLauncher.Launcher.getInstallations()[0] ?? '';
    if (!chromePath) {
        const data = fs.readFileSync('./PrinterConfig.txt', 'utf8');
        var config = JSON.parse(data);
        if (config && config['ChromeExePath']) {
            chromePath = config['ChromeExePath'];
        }
    }
    return chromePath;
};

async function getBrowserPage() {
    // if (myBrowser) {
    //     try {
    //         const myPage = await myBrowser.newPage()
    //         return { browser: myBrowser, page: myPage }
    //     } catch (err) {
    //         console.error(`Puppeteer cannot find browser instance. ${err}`)
    //     }
    // }

    // const chromeFlags = [
    //     "--no-sandbox",
    //     "--disable-gpu",
    //     "--headless",
    //     "--single-process",
    //     "--no-zygote",
    // ]
    // const args = ["--disable-setuid-sandbox", ...chromeFlags]


    var param = {
        headless: 'new',
        devtools: false,
        ignoreHTTPSErrors: true,
        slowMo: 0,
        ignoreDefaultArgs: ["--disable-extensions"], // Required.
        args: [
            '--disk-cache-size=1',
            '--headless',
            '--disable-crash-reporter',
            '--disable-breakpad',
            '--disable-features=site-per-process',
            '--disable-features=SitePerProcess',
            '--no-sandbox',
            '--no-zygote',
            //'--disable-accelerated-2d-canvas', '--disable-dev-shm-usage',
            "--proxy-server='direct://'",
            "--proxy-bypass-list=*",
            '--disable-notifications',
            '--disable-geolocation',
            '--disable-infobars',
            '--disable-extensions',
            '--disable-session-crashed-bubble',
            '--disable-gpu',
            '--disable-force-compositing-mode',
            //'--disable-features=NetworkService',
            '--disable-audio-output',
            '--mute-audio',
            '--silent-debugger-extension-api',
            //'--single-process',
            '--disable-setuid-sandbox',
            //'--full-memory-crash-report',
            //'--unlimited-storage'
        ]
    }
    const chromePath = getChromePath();
    if (chromePath) {
        param['executablePath'] = chromePath;
    }
    const browser = await puppeteer.launch(param)
    const page = await browser.newPage()
    return { browser, page };
}
module.exports = {
    getChromePath,
    getBrowserPage
}
