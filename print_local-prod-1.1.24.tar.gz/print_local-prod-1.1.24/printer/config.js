/*
 * @copyright
 * Copyright (c) 2020 OVTeam
 *
 * All Rights Reserved
 *
 * Licensed under the MIT License;
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://choosealicense.com/licenses/mit/
 *
 */

const jwtDecode = require("jwt-decode");
const WHLIST = {}

function setConfig(name, val) {
    if (typeof (val) === 'object') {
        val = JSON.stringify(val);
    }
    process.env[name] = val;
}

exports.loadDefault = () => {
    const configs = require("./conf.json");

    for (let cfg in configs) {
        setConfig(cfg, configs[cfg])
    }
}
