const Config = require("./config");
const service = require('node-windows').Service
Config.loadDefault();
var name = process.env.ServiceName || 'PrintLocal';  
var svc = new service({
  name:name,
  description: 'Print Service',
  script: './index.js'
});
svc.on('install',function(){
  svc.start();
  
});
svc.on('alreadyinstalled',function(){
  console.log('This service is already installed.');
});

svc.on('uninstall',function(){
  console.log('This service is already uninstalled.');
});


svc.on('start',function(){
  console.log(name + ' started!\n at http://127.0.0.1:' + process.env.PORT);
});

svc.install();
