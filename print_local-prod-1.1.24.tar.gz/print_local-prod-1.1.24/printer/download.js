const fs = require("fs");
const http = require("http");
const https = require("https");
const url = require("url");
const browserPage = require("./browserPage.js");
const logger = require('./logger');

async function adapterFor() {
	const adapters = {
		"http:": http,
		"https:": https,
	}

	return function (inputUrl) {
		return adapters[url.parse(inputUrl).protocol]
	}
};

async function downloadFile(body) {
	return new Promise((resolve, reject) => {
		const { existed, absolutePath, publicUrl } = makePaths(body)

		if (existed) {
			resolve({ publicUrl })
		}

		const fileStream = fs.createWriteStream(absolutePath)

		const url = body.content

		adapterFor(url)
			.get(url, (response) => {
				response.pipe(fileStream)

				fileStream.on("finish", () => {
					fileStream.close()
					console.log(
						`File đã được tải và lưu thành công. content = ${url}, result: ${absolutePath}. publicUrl: ${publicUrl}`
					)
					resolve({ publicUrl })
				})

				fileStream.on("error", (err) => {
					if (!fileStream.closed) fileStream.close()
					console.error(
						`Lỗi ghi file. content = ${url}. error: `,
						err
					)
					reject(err)
				})
			})
			.on("error", (err) => {
				console.error(
					`Lỗi trong quá trình tải file. content = ${url}. error:`,
					err
				)
				if (!fileStream.closed) fileStream.close()
				reject(err)
			})
	})
}

async function crawEncodedHTML(content, print_option, fileName) {
	try {
		const { browser, page } = await browserPage.getBrowserPage();
		const outpath = './uploads/' + fileName + ".pdf";
		await page.setContent(content);
		page.on('console', (msg) => console.log(`PAGE LOG: ${msg.text()}`));
		page.on('pageerror', (err) => console.error('PAGE ERROR:', err));
		await page.pdf({
			path: outpath,
			printBackground: true, ...
			print_option
		});
		page.close().then(() => {
			console.log('browser#close()')
			browser.close();
		})
		return {
			success: true,
			url: outpath
		}
		//   result.success != true || !result.url
		//   page.close().then(() => {
		//                         console.log('browser#close()')

		//                         // Close the browser so that the Node.js process can
		//                         // exit.
		//                         browser.close();
		//                     })

		// await page.setContent(decodeBase64(content))
		// const { publicUrl } = await storePdf(page, body)
		// if (!page.isClosed) await page.close()
		// // if (browser.isConnected()) await browser.close()
		// return publicUrl
	} catch (err) {
		logger.logError(err);
		return {
			success: false,
			url: ''
		}
	}
}

async function decodeBase64(str) {
	const decoded = Buffer.from(str, "base64").toString("utf8")
	return decoded
}

module.exports = {
	adapterFor,
	downloadFile,
	crawEncodedHTML
}