const express = require('express');
const cors = require('cors');
const multer = require("multer");
const fs = require('fs')
const https = require('https')
const { exec } = require("child_process")
const { getPrinters } = require("pdf-to-printer")
const path = require("path");
const Config = require("./config");
const Ultils = require('./Utils');
const logger = require('./logger');
const http = require('http');
const url = require('url');
const { networkInterfaces } = require('os');
const os = require('os')
const browserPage = require("./browserPage.js");
const Version = "1.0.0.6";
const OS_LINUX = 'LINUX';

const adapterFor = (function () {
  const adapters = {
    'http:': http,
    'https:': https,
  }

  return function (inputUrl) {
    return adapters[url.parse(inputUrl).protocol]
  }
}())

function logErrors(err, req, res, next) {
  logger.log(err.stack)
  next(err)
}

const app = express()
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({
  extended: true
}))

app.set("view engine", "jade")

app.use(express.static('public'))

Config.loadDefault();
const port = process.env.PORT || 5001;
app.get("/", async (req, res) => {
  var printers = await getPrinterLists();

  let printerLists = [];
  printers.forEach((e) => {
    printerLists.push({ value: e.name, label: e.name })
  })
  res.render('index', { printers: printerLists })
})

app.get("/getPrinterList", async (req, res) => {
  const printers = await getPrinterLists();
  res.json({ printers });
});

app.get("/getPrinterConfig", async (req, res) => {
  var config = Ultils.readFilePrinterConfig();
  res.set({ 'Content-Type': 'application/xml' });
  res.send(`<note>
     <div>${JSON.stringify(config)}</div>  
     </note>`
  )
});

app.get("/healthy", async (req, res) => {
  try {
    var deviceInfo = actionGetDeviceInfo();
    res.set({ 'Content-Type': 'application/xml' });
    res.send(`<note>
     <div>Service: healthy</div>
     <div>Version: ${Version}</div>
     <div>DeviceInfo: ${JSON.stringify(deviceInfo)}</div>
     </note>`
    )
  }
  catch (err) {
    logger.logError(err)
  }
});

app.get("/getdeviceinfo", async (req, res) => {
  var deviceInfo = actionGetDeviceInfo();
  res.json(deviceInfo);
});

app.get("/uatwindows/print", async (req, res) => {
  var body = {
    "printtrackingcode": "Test_UAT_Windows_Print",
    "data": "eyJsYWJlbCI6IkluIG5ow6NuIHbhuq1uIGNodXnhu4NuLiIsInByaW50ZXJfbmFtZSI6IlByaW50ZXJMYWJlbCIsInByaW50ZXIiOiJTaGlucHBpbmdMYWJlbF9BQUQiLCJwcmludGVyRGVmYXVsdCI6IlNoaXBwaW5nTGFiZWxBNyIsInRlbXBsYXRlIjoiQWxsU2hpcHBpbmdMYWJlbEE3VUFUIiwiZGF0YSI6eyJFeHRyYVNlcnZpY2VDb2RlIjpudWxsLCJFeHRyYVNlcnZpY2VzIjpbXSwiTGlzdFNoaXBwaW5nTGFiZWwiOlt7IlNvSWQiOjU2ODcwNCwiU29Db2RlIjoiU09BQURYRFI2SFpSSCIsIkV4dGVybmFsQ29kZSI6IlNPQUFEWERSNkhaUkgiLCJJZFJlZ2lvblNvQ29kZSI6ImlkUmVnaW9uX1NPQUFEWERSNkhaUkgiLCJMb2dvRXRvbiI6Ii9Db250ZW50L2ltYWdlcy9sb2dvLnBuZyIsIkxvZ29DbGllbnQiOiIiLCJMb2dvQzNQbCI6bnVsbCwiUGF0aFVybCI6IiIsIkNsaWVudElkIjozLCJIb3RMaW5lQ2xpZW50IjpudWxsLCJXYXJlaG91c2VJZCI6NywiV2FyZWhvdXNlQ29kZSI6IjA1IiwiV2FyZWhvdXNlTmFtZSI6IlE3IEZDIiwiV2FyZWhvdXNlQWRkcmVzcyI6IiA5NiDEkcOgbyB0csOtLCBwaMaw4budbmcgcGjDuiB0aHXhuq1uLCBxNyIsIkN1c3RvbWVySWQiOjAsIlNoaXBwaW5nT3JkZXJOYW1lIjoiU2hvcGVlXzY5NTA4IiwiU2hpcHBpbmdPcmRlckFkZHJlc3MiOiIxMiwgUGjGsOG7nW5nIFTDom4gxJDhu4tuaCwgUXXhuq1uIDEsIFRow6BuaCBwaOG7kSBI4buTIENow60gTWluaCIsIlNoaXBwaW5nT3JkZXJQaG9uZSI6IioqKioqKioyMjIgLSBCw6xuaCIsIkludm9pY2VHcm91cCI6MSwiVG90YWxHcm91cCI6MSwiU3RyRm9ybWF0R3JvdXAiOiIxIC8gMSIsIkludm9pY2VObyI6IjA1QUFEMjVCMTAwMDYzMSIsIlNvQ2xpZW50IjoiU09BQURYRFI2SFpSSCIsIlNoaXBwaW5nTm90ZSI6InRlc3QiLCJIYXNDbGllbnRQaWNrVXAiOmZhbHNlLCJGaW5hbENvZCI6IjAiLCJOYW1lQzNQTCI6IkomVCBFeHByZXNzIiwiVHJhY2tpbmdDb2RlIjoiSjA1QUFEMjVCMTAwMDYzMSIsIlBhY2tlZERhdGUiOiIxMy8wMi8yMDI1IDE0OjQ2IiwiRXhwZWN0RGVsaXZlcnlEYXRlIjoiIiwiQ2xpZW50UGlja3VwIjpmYWxzZSwiRG9jdW1lbnRJbnZvaWNlIjpbXSwiSW5kZXhObyI6IjA1QUFEMjVCMTAwMDYzMSIsIklkVHJhY2tpbmdDb2RlIjoiZXRvbl9UcmFja2luZ0NvZGVfMDVBQUQyNUIxMDAwNjMxIiwiSWRFeHRlcm5hbENvZGUiOiJldG9uX0V4dGVybmFsQ29kZV8wNUFBRDI1QjEwMDA2MzEiLCJJZFNvQ29kZSI6ImV0b25fU09Db2RlXzA1QUFEMjVCMTAwMDYzMSIsIklkSW52b2ljZU5vIjoiZXRvbl9JbnZvaWNlTm9fMDVBQUQyNUIxMDAwNjMxIiwiRm9ybWF0V2VpZ2h0IjoiMC4wNCIsIklzRXRvbkRlbGl2ZXJ5U2VydmljZSI6ZmFsc2UsIlNvcnRDb2RlIjoiMk1fMTMtQSIsIlJvdXRlUHJpb3JpdHkiOm51bGwsIkN1c3RvbWVyTmFtZSI6bnVsbCwiQ3VzdG9tZXJQaG9uZSI6bnVsbCwiU29ydENvZGUxIjoiODAwLTAyOEEwMiIsIlNvcnRDb2RlMiI6bnVsbCwiU2hvcnROYW1lQzNQTCI6IkomVCIsIlJlZkV4dGVybmFsQ29kZSI6bnVsbCwiVG90YWxVbml0cyI6NCwiSG90bGluZSI6IjAyNjU5NjI1NjU1IiwiQ29udGFjdFBob25lIjpudWxsLCJTb3J0Q29kZUFuZFJvdXRlUHJpb3JpdHkiOiIyTV8xMy1BIiwiT3JkaW5hbE51bWJlck9mU28iOiIxMDAwNjMiLCJTb0lzQ2FuY2VsbGVkIjpmYWxzZSwiQ2xpZW50UGlja1VwSW5mbyI6IiIsIlNoaXBwaW5nTm90ZUZvckNsaWVudFBpY2tVcCI6IiIsIlNoaXBwaW5nT3JkZXJQaG9uZU9yaWdpbiI6IioqKioqKioyMjIiLCJTb3J0Q29kZTNQbCI6bnVsbCwiU2hvd1NvcnRDb2RlM1BsIjpmYWxzZSwiU2hvd1NvcnRDb2RlQW5kUm91dGVQcmlvcml0eSI6dHJ1ZSwiU2hvd05vdGUiOnRydWUsIkNsaWVudENvZGUiOiJBQUQiLCJDbGllbnROYW1lIjoiQ8O0bmcgdHkgVE5ISCDEkOG6p3UgdMawIFRoacOqbiDDgm4gYmluaHRlc3QiLCJIb3RsaW5lQ2xpZW50QnJhbmNoIjpudWxsLCJDbGllbnRCcmFuY2hDb2RlIjoiNjk1MDgiLCJEZWxpdmVyeVN0YXRpb24iOm51bGwsIkNsaWVudFNob3J0TmFtZSI6IkFBRCJ9XSwiSXNEZWFkbGluZVNoaXBwaW5nVGVtcGxhdGUiOmZhbHNlLCJTb3J0Q29kZSI6IjJNXzEzLUEiLCJTaGlwcGluZ1NlcnZpY2VDb2RlIjoiU1REIiwiRGVsaXZlcnlEZWFkbGluZSI6IjE0LzAyLzIwMjUiLCJEZWxpdmVyeURlYWRsaW5lSG91ciI6IjE1OjAwIiwibGFuZ3VhZ2VzIjp7IlBob25lX1NoaXBwaW5nbGFibGUiOiJTxJBUIiwiQWRkcmVzcyI6IsSQ4buLYSBjaOG7iSIsIlNoaXBwaW5nTGFiZWwiOiJNw6MgbmjDo24gduG6rW4gY2h1eeG7g24iLCJTT0NvZGUiOiJNw6MgU08iLCJLZyI6IktnIiwiTm90ZSI6IkdoaSBjaMO6In0sIkN1cnJlbnRUaW1lIjoiMTcvMDIgMTc6NDYifSwidXJsIjoiIiwicHJpbnRUZW1wbGF0ZU1hcHBpbmciOnsiRG9jdW1lbnRUeXBlIjoiU2hpcHBpbmdMYWJlbEIyQiIsIkNsaWVudENvZGUiOm51bGwsIlRlbXBsYXRlQ29kZSI6IkFsbFNoaXBwaW5nTGFiZWxBN1VBVCIsIk9iamVjdFR5cGUiOiJTYWxlT3JkZXIiLCJQcmludE9wdGlvbnMiOnsic2NhbGUiOjEsInBhZ2VTaXplIjoiQTciLCJvcmllbnRhdGlvbiI6IkxhbmRzY2FwZSJ9LCJJc0FjdGl2ZSI6dHJ1ZX19"
  }
  req.body = body;
  await handlePrintRequest(req, res);
});

app.get("/uatlinux/print", async (req, res) => {
  var body = {
    "os": "LINUX",
    "printtrackingcode": "Test_UAT_Linux_Print",
    "data": "eyJsYWJlbCI6IkluIG5ow6NuIHbhuq1uIGNodXnhu4NuLiIsInByaW50ZXJfbmFtZSI6IlByaW50ZXJMYWJlbCIsInByaW50ZXIiOiJTaGlucHBpbmdMYWJlbF9BQUQiLCJwcmludGVyRGVmYXVsdCI6IlNoaXBwaW5nTGFiZWxBNyIsInRlbXBsYXRlIjoiQWxsU2hpcHBpbmdMYWJlbEE3VUFUIiwiZGF0YSI6eyJFeHRyYVNlcnZpY2VDb2RlIjpudWxsLCJFeHRyYVNlcnZpY2VzIjpbXSwiTGlzdFNoaXBwaW5nTGFiZWwiOlt7IlNvSWQiOjU2ODcwNCwiU29Db2RlIjoiU09BQURYRFI2SFpSSCIsIkV4dGVybmFsQ29kZSI6IlNPQUFEWERSNkhaUkgiLCJJZFJlZ2lvblNvQ29kZSI6ImlkUmVnaW9uX1NPQUFEWERSNkhaUkgiLCJMb2dvRXRvbiI6Ii9Db250ZW50L2ltYWdlcy9sb2dvLnBuZyIsIkxvZ29DbGllbnQiOiIiLCJMb2dvQzNQbCI6bnVsbCwiUGF0aFVybCI6IiIsIkNsaWVudElkIjozLCJIb3RMaW5lQ2xpZW50IjpudWxsLCJXYXJlaG91c2VJZCI6NywiV2FyZWhvdXNlQ29kZSI6IjA1IiwiV2FyZWhvdXNlTmFtZSI6IlE3IEZDIiwiV2FyZWhvdXNlQWRkcmVzcyI6IiA5NiDEkcOgbyB0csOtLCBwaMaw4budbmcgcGjDuiB0aHXhuq1uLCBxNyIsIkN1c3RvbWVySWQiOjAsIlNoaXBwaW5nT3JkZXJOYW1lIjoiU2hvcGVlXzY5NTA4IiwiU2hpcHBpbmdPcmRlckFkZHJlc3MiOiIxMiwgUGjGsOG7nW5nIFTDom4gxJDhu4tuaCwgUXXhuq1uIDEsIFRow6BuaCBwaOG7kSBI4buTIENow60gTWluaCIsIlNoaXBwaW5nT3JkZXJQaG9uZSI6IioqKioqKioyMjIgLSBCw6xuaCIsIkludm9pY2VHcm91cCI6MSwiVG90YWxHcm91cCI6MSwiU3RyRm9ybWF0R3JvdXAiOiIxIC8gMSIsIkludm9pY2VObyI6IjA1QUFEMjVCMTAwMDYzMSIsIlNvQ2xpZW50IjoiU09BQURYRFI2SFpSSCIsIlNoaXBwaW5nTm90ZSI6InRlc3QiLCJIYXNDbGllbnRQaWNrVXAiOmZhbHNlLCJGaW5hbENvZCI6IjAiLCJOYW1lQzNQTCI6IkomVCBFeHByZXNzIiwiVHJhY2tpbmdDb2RlIjoiSjA1QUFEMjVCMTAwMDYzMSIsIlBhY2tlZERhdGUiOiIxMy8wMi8yMDI1IDE0OjQ2IiwiRXhwZWN0RGVsaXZlcnlEYXRlIjoiIiwiQ2xpZW50UGlja3VwIjpmYWxzZSwiRG9jdW1lbnRJbnZvaWNlIjpbXSwiSW5kZXhObyI6IjA1QUFEMjVCMTAwMDYzMSIsIklkVHJhY2tpbmdDb2RlIjoiZXRvbl9UcmFja2luZ0NvZGVfMDVBQUQyNUIxMDAwNjMxIiwiSWRFeHRlcm5hbENvZGUiOiJldG9uX0V4dGVybmFsQ29kZV8wNUFBRDI1QjEwMDA2MzEiLCJJZFNvQ29kZSI6ImV0b25fU09Db2RlXzA1QUFEMjVCMTAwMDYzMSIsIklkSW52b2ljZU5vIjoiZXRvbl9JbnZvaWNlTm9fMDVBQUQyNUIxMDAwNjMxIiwiRm9ybWF0V2VpZ2h0IjoiMC4wNCIsIklzRXRvbkRlbGl2ZXJ5U2VydmljZSI6ZmFsc2UsIlNvcnRDb2RlIjoiMk1fMTMtQSIsIlJvdXRlUHJpb3JpdHkiOm51bGwsIkN1c3RvbWVyTmFtZSI6bnVsbCwiQ3VzdG9tZXJQaG9uZSI6bnVsbCwiU29ydENvZGUxIjoiODAwLTAyOEEwMiIsIlNvcnRDb2RlMiI6bnVsbCwiU2hvcnROYW1lQzNQTCI6IkomVCIsIlJlZkV4dGVybmFsQ29kZSI6bnVsbCwiVG90YWxVbml0cyI6NCwiSG90bGluZSI6IjAyNjU5NjI1NjU1IiwiQ29udGFjdFBob25lIjpudWxsLCJTb3J0Q29kZUFuZFJvdXRlUHJpb3JpdHkiOiIyTV8xMy1BIiwiT3JkaW5hbE51bWJlck9mU28iOiIxMDAwNjMiLCJTb0lzQ2FuY2VsbGVkIjpmYWxzZSwiQ2xpZW50UGlja1VwSW5mbyI6IiIsIlNoaXBwaW5nTm90ZUZvckNsaWVudFBpY2tVcCI6IiIsIlNoaXBwaW5nT3JkZXJQaG9uZU9yaWdpbiI6IioqKioqKioyMjIiLCJTb3J0Q29kZTNQbCI6bnVsbCwiU2hvd1NvcnRDb2RlM1BsIjpmYWxzZSwiU2hvd1NvcnRDb2RlQW5kUm91dGVQcmlvcml0eSI6dHJ1ZSwiU2hvd05vdGUiOnRydWUsIkNsaWVudENvZGUiOiJBQUQiLCJDbGllbnROYW1lIjoiQ8O0bmcgdHkgVE5ISCDEkOG6p3UgdMawIFRoacOqbiDDgm4gYmluaHRlc3QiLCJIb3RsaW5lQ2xpZW50QnJhbmNoIjpudWxsLCJDbGllbnRCcmFuY2hDb2RlIjoiNjk1MDgiLCJEZWxpdmVyeVN0YXRpb24iOm51bGwsIkNsaWVudFNob3J0TmFtZSI6IkFBRCJ9XSwiSXNEZWFkbGluZVNoaXBwaW5nVGVtcGxhdGUiOmZhbHNlLCJTb3J0Q29kZSI6IjJNXzEzLUEiLCJTaGlwcGluZ1NlcnZpY2VDb2RlIjoiU1REIiwiRGVsaXZlcnlEZWFkbGluZSI6IjE0LzAyLzIwMjUiLCJEZWxpdmVyeURlYWRsaW5lSG91ciI6IjE1OjAwIiwibGFuZ3VhZ2VzIjp7IlBob25lX1NoaXBwaW5nbGFibGUiOiJTxJBUIiwiQWRkcmVzcyI6IsSQ4buLYSBjaOG7iSIsIlNoaXBwaW5nTGFiZWwiOiJNw6MgbmjDo24gduG6rW4gY2h1eeG7g24iLCJTT0NvZGUiOiJNw6MgU08iLCJLZyI6IktnIiwiTm90ZSI6IkdoaSBjaMO6In0sIkN1cnJlbnRUaW1lIjoiMTcvMDIgMTc6NDYifSwidXJsIjoiIiwicHJpbnRUZW1wbGF0ZU1hcHBpbmciOnsiRG9jdW1lbnRUeXBlIjoiU2hpcHBpbmdMYWJlbEIyQiIsIkNsaWVudENvZGUiOm51bGwsIlRlbXBsYXRlQ29kZSI6IkFsbFNoaXBwaW5nTGFiZWxBN1VBVCIsIk9iamVjdFR5cGUiOiJTYWxlT3JkZXIiLCJQcmludE9wdGlvbnMiOnsic2NhbGUiOjEsInBhZ2VTaXplIjoiQTciLCJvcmllbnRhdGlvbiI6IkxhbmRzY2FwZSJ9LCJJc0FjdGl2ZSI6dHJ1ZX19"
  }
  req.body = body;
  await handlePrintRequest(req, res);
});

app.get("/windows/print", async (req, res) => {
  var body = {
    "printtrackingcode": "Test_Windows_Print",
    "data": "eyJsYWJlbCI6IkluIG5ow6NuIHbhuq1uIGNodXnhu4NuLiIsInByaW50ZXJfbmFtZSI6IlByaW50ZXJMYWJlbCIsInByaW50ZXIiOiJTaGlwcGluZ0xhYmVsQjJDX01TTiIsInByaW50ZXJEZWZhdWx0IjoiU2hpcHBpbmdMYWJlbEIyQ0E3IiwidGVtcGxhdGUiOiJTaGlwcGluZ0xhYmVsQjJDQTciLCJkYXRhIjp7IkV4dHJhU2VydmljZUNvZGUiOm51bGwsIkxpc3RTaGlwcGluZ0xhYmVsIjpbeyJTb0lkIjoxMTI3ODE3OCwiU29Db2RlIjoiU09NU05JWk1HQ0tIRyIsIkV4dGVybmFsQ29kZSI6IkNLU1FEMTEyNjM5LTQ3Mjc3NTAiLCJJZFJlZ2lvblNvQ29kZSI6ImlkUmVnaW9uX1NPTVNOSVpNR0NLSEciLCJMb2dvRXRvbiI6Ii9Db250ZW50L2ltYWdlcy9sb2dvLnBuZyIsIkxvZ29DbGllbnQiOiIiLCJMb2dvQzNQbCI6Imh0dHBzOi8vbWVwLmV0b24udm4vbW50L2V0b24vaW1hZ2VzL25pbmphdmFuLWxvZ28tcHJpbnRfZTg3ZDU0OTgtYWFhOC00MDAyLWFhZTEtZDJhY2I1NmQwMjk0LnBuZyIsIlBhdGhVcmwiOiIiLCJDbGllbnRJZCI6MTAxMzgsIkhvdExpbmVDbGllbnQiOm51bGwsIldhcmVob3VzZUlkIjo3LCJXYXJlaG91c2VDb2RlIjoiMDQiLCJXYXJlaG91c2VOYW1lIjoiUTcgRkMiLCJXYXJlaG91c2VBZGRyZXNzIjoiOTYgxJDDoG8gVHLDrSwgUGjGsOG7nW5nIFBow7ogVGh14bqtbiwgUXXhuq1uIDcsIFRow6BuaCBwaOG7kSBI4buTIENow60gTWluaCIsIkN1c3RvbWVySWQiOjE0NjA1MDY5LCJTaGlwcGluZ09yZGVyTmFtZSI6IlTDom0iLCJTaGlwcGluZ09yZGVyQWRkcmVzcyI6IjE1Ny8xMy81MkEsIMSRxrDhu51uZyBEMiwgcDI1LCBCw6xuaCBUaOG6oW5oLCBIQ00sIFBoxrDhu51uZyAyNSwgUXXhuq1uIELDrG5oIFRo4bqhbmgsIFRow6BuaCBwaOG7kSBI4buTIENow60gTWluaCIsIlNoaXBwaW5nT3JkZXJQaG9uZSI6IjA4NTgyODEzMjggLSBUw6JtIiwiSW52b2ljZUdyb3VwIjoxLCJUb3RhbEdyb3VwIjoxLCJTdHJGb3JtYXRHcm91cCI6IjEgLyAxIiwiSW52b2ljZU5vIjoiMDRNU04yNUM0Njk0NTExIiwiU29DbGllbnQiOiJDS1NRRDExMjYzOS00NzI3NzUwIiwiU2hpcHBpbmdOb3RlIjpudWxsLCJIYXNDbGllbnRQaWNrVXAiOmZhbHNlLCJGaW5hbENvZCI6IjAiLCJOYW1lQzNQTCI6IkPDtG5nIHR5IFROSEggTmluamFWYW4iLCJUcmFja2luZ0NvZGUiOiJFVE9OMDRNU04yNUM0Njk0NTExIiwiUGFja2VkRGF0ZSI6IjI2LzAzLzIwMjUgMTI6NTciLCJFeHBlY3REZWxpdmVyeURhdGUiOiIyNy8wMy8yMDI1IiwiQ2xpZW50UGlja3VwIjpmYWxzZSwiRG9jdW1lbnRJbnZvaWNlIjpbXSwiSW5kZXhObyI6IjA0TVNOMjVDNDY5NDUxMSIsIklkVHJhY2tpbmdDb2RlIjoiZXRvbl9UcmFja2luZ0NvZGVfMDRNU04yNUM0Njk0NTExIiwiSWRFeHRlcm5hbENvZGUiOiJldG9uX0V4dGVybmFsQ29kZV8wNE1TTjI1QzQ2OTQ1MTEiLCJJZFNvQ29kZSI6ImV0b25fU09Db2RlXzA0TVNOMjVDNDY5NDUxMSIsIklkSW52b2ljZU5vIjoiZXRvbl9JbnZvaWNlTm9fMDRNU04yNUM0Njk0NTExIiwiRm9ybWF0V2VpZ2h0IjoiMC4wNCIsIklzRXRvbkRlbGl2ZXJ5U2VydmljZSI6ZmFsc2UsIlNvcnRDb2RlIjoiMk1fMTMtQiIsIlJvdXRlUHJpb3JpdHkiOm51bGwsIkN1c3RvbWVyTmFtZSI6IlTDom0iLCJDdXN0b21lclBob25lIjoiMDg1ODI4MTMyOCIsIlNvcnRDb2RlMSI6bnVsbCwiU29ydENvZGUyIjpudWxsLCJTaG9ydE5hbWVDM1BMIjoiTmluamFWYW4iLCJSZWZFeHRlcm5hbENvZGUiOiJDS1NRRDExMjYzOSIsIlRvdGFsVW5pdHMiOjIsIkhvdGxpbmUiOm51bGwsIkNvbnRhY3RQaG9uZSI6bnVsbCwiU29ydENvZGVBbmRSb3V0ZVByaW9yaXR5IjoiMk1fMTMtQiIsIk9yZGluYWxOdW1iZXJPZlNvIjoiNDY5NDUxIiwiU29Jc0NhbmNlbGxlZCI6ZmFsc2UsIkNsaWVudFBpY2tVcEluZm8iOiIiLCJTaGlwcGluZ05vdGVGb3JDbGllbnRQaWNrVXAiOiIiLCJTaGlwcGluZ09yZGVyUGhvbmVPcmlnaW4iOiIwODU4MjgxMzI4IiwiU29ydENvZGUzUGwiOm51bGwsIlNob3dTb3J0Q29kZTNQbCI6ZmFsc2UsIlNob3dTb3J0Q29kZUFuZFJvdXRlUHJpb3JpdHkiOnRydWUsIlNob3dOb3RlIjpmYWxzZSwiQ2xpZW50Q29kZSI6Ik1TTiIsIkNsaWVudE5hbWUiOiJDw5RORyBUWSBUTkhIIE3hu7ggUEjhuqhNIE1FSVNIQU5HIFZJ4buGVCBOQU0iLCJIb3RsaW5lQ2xpZW50QnJhbmNoIjpudWxsLCJDbGllbnRCcmFuY2hDb2RlIjpudWxsLCJEZWxpdmVyeVN0YXRpb24iOm51bGx9XSwiRXh0cmFTZXJ2aWNlcyI6W10sIklzRGVhZGxpbmVTaGlwcGluZ1RlbXBsYXRlIjpmYWxzZSwiU29ydENvZGUiOiIyTV8xMy1CIiwiU2hpcHBpbmdTZXJ2aWNlQ29kZSI6IkVUT04gQkNTIiwiRGVsaXZlcnlEZWFkbGluZSI6IjI3LzAzLzIwMjUiLCJEZWxpdmVyeURlYWRsaW5lSG91ciI6IjEwOjAwIiwibGFuZ3VhZ2VzIjp7IlNoaXBwaW5nTGFiZWwiOiJNw6MgbmjDo24gduG6rW4gY2h1eeG7g24iLCJTT0NvZGUiOiJNw6MgU08iLCJOb3RlIjoiR2hpIGNow7oifSwiQ3VycmVudFRpbWUiOiIyNy8wMyAxNTowNCJ9LCJ1cmwiOiIiLCJwcmludFRlbXBsYXRlTWFwcGluZyI6eyJEb2N1bWVudFR5cGUiOiJTaGlwcGluZ0xhYmVsQjJDIiwiQ2xpZW50Q29kZSI6bnVsbCwiVGVtcGxhdGVDb2RlIjoiU2hpcHBpbmdMYWJlbEIyQ0E3IiwiT2JqZWN0VHlwZSI6IlNhbGVPcmRlciIsIlByaW50T3B0aW9ucyI6eyJzY2FsZSI6MSwicGFnZVNpemUiOiJBNyIsIm9yaWVudGF0aW9uIjoiTGFuZHNjYXBlIn0sIklzQWN0aXZlIjp0cnVlfX0="
  }
  req.body = body;
  await handlePrintRequest(req, res);
});

app.get("/linux/print", async (req, res) => {
  var body = {
    "os": "LINUX",
    "printtrackingcode": "Test_Linux_Print",
    "data": "eyJsYWJlbCI6IkluIG5ow6NuIHbhuq1uIGNodXnhu4NuLiIsInByaW50ZXJfbmFtZSI6IlByaW50ZXJMYWJlbCIsInByaW50ZXIiOiJTaGlwcGluZ0xhYmVsQjJDX01TTiIsInByaW50ZXJEZWZhdWx0IjoiU2hpcHBpbmdMYWJlbEIyQ0E3IiwidGVtcGxhdGUiOiJTaGlwcGluZ0xhYmVsQjJDQTciLCJkYXRhIjp7IkV4dHJhU2VydmljZUNvZGUiOm51bGwsIkxpc3RTaGlwcGluZ0xhYmVsIjpbeyJTb0lkIjoxMTI3ODE3OCwiU29Db2RlIjoiU09NU05JWk1HQ0tIRyIsIkV4dGVybmFsQ29kZSI6IkNLU1FEMTEyNjM5LTQ3Mjc3NTAiLCJJZFJlZ2lvblNvQ29kZSI6ImlkUmVnaW9uX1NPTVNOSVpNR0NLSEciLCJMb2dvRXRvbiI6Ii9Db250ZW50L2ltYWdlcy9sb2dvLnBuZyIsIkxvZ29DbGllbnQiOiIiLCJMb2dvQzNQbCI6Imh0dHBzOi8vbWVwLmV0b24udm4vbW50L2V0b24vaW1hZ2VzL25pbmphdmFuLWxvZ28tcHJpbnRfZTg3ZDU0OTgtYWFhOC00MDAyLWFhZTEtZDJhY2I1NmQwMjk0LnBuZyIsIlBhdGhVcmwiOiIiLCJDbGllbnRJZCI6MTAxMzgsIkhvdExpbmVDbGllbnQiOm51bGwsIldhcmVob3VzZUlkIjo3LCJXYXJlaG91c2VDb2RlIjoiMDQiLCJXYXJlaG91c2VOYW1lIjoiUTcgRkMiLCJXYXJlaG91c2VBZGRyZXNzIjoiOTYgxJDDoG8gVHLDrSwgUGjGsOG7nW5nIFBow7ogVGh14bqtbiwgUXXhuq1uIDcsIFRow6BuaCBwaOG7kSBI4buTIENow60gTWluaCIsIkN1c3RvbWVySWQiOjE0NjA1MDY5LCJTaGlwcGluZ09yZGVyTmFtZSI6IlTDom0iLCJTaGlwcGluZ09yZGVyQWRkcmVzcyI6IjE1Ny8xMy81MkEsIMSRxrDhu51uZyBEMiwgcDI1LCBCw6xuaCBUaOG6oW5oLCBIQ00sIFBoxrDhu51uZyAyNSwgUXXhuq1uIELDrG5oIFRo4bqhbmgsIFRow6BuaCBwaOG7kSBI4buTIENow60gTWluaCIsIlNoaXBwaW5nT3JkZXJQaG9uZSI6IjA4NTgyODEzMjggLSBUw6JtIiwiSW52b2ljZUdyb3VwIjoxLCJUb3RhbEdyb3VwIjoxLCJTdHJGb3JtYXRHcm91cCI6IjEgLyAxIiwiSW52b2ljZU5vIjoiMDRNU04yNUM0Njk0NTExIiwiU29DbGllbnQiOiJDS1NRRDExMjYzOS00NzI3NzUwIiwiU2hpcHBpbmdOb3RlIjpudWxsLCJIYXNDbGllbnRQaWNrVXAiOmZhbHNlLCJGaW5hbENvZCI6IjAiLCJOYW1lQzNQTCI6IkPDtG5nIHR5IFROSEggTmluamFWYW4iLCJUcmFja2luZ0NvZGUiOiJFVE9OMDRNU04yNUM0Njk0NTExIiwiUGFja2VkRGF0ZSI6IjI2LzAzLzIwMjUgMTI6NTciLCJFeHBlY3REZWxpdmVyeURhdGUiOiIyNy8wMy8yMDI1IiwiQ2xpZW50UGlja3VwIjpmYWxzZSwiRG9jdW1lbnRJbnZvaWNlIjpbXSwiSW5kZXhObyI6IjA0TVNOMjVDNDY5NDUxMSIsIklkVHJhY2tpbmdDb2RlIjoiZXRvbl9UcmFja2luZ0NvZGVfMDRNU04yNUM0Njk0NTExIiwiSWRFeHRlcm5hbENvZGUiOiJldG9uX0V4dGVybmFsQ29kZV8wNE1TTjI1QzQ2OTQ1MTEiLCJJZFNvQ29kZSI6ImV0b25fU09Db2RlXzA0TVNOMjVDNDY5NDUxMSIsIklkSW52b2ljZU5vIjoiZXRvbl9JbnZvaWNlTm9fMDRNU04yNUM0Njk0NTExIiwiRm9ybWF0V2VpZ2h0IjoiMC4wNCIsIklzRXRvbkRlbGl2ZXJ5U2VydmljZSI6ZmFsc2UsIlNvcnRDb2RlIjoiMk1fMTMtQiIsIlJvdXRlUHJpb3JpdHkiOm51bGwsIkN1c3RvbWVyTmFtZSI6IlTDom0iLCJDdXN0b21lclBob25lIjoiMDg1ODI4MTMyOCIsIlNvcnRDb2RlMSI6bnVsbCwiU29ydENvZGUyIjpudWxsLCJTaG9ydE5hbWVDM1BMIjoiTmluamFWYW4iLCJSZWZFeHRlcm5hbENvZGUiOiJDS1NRRDExMjYzOSIsIlRvdGFsVW5pdHMiOjIsIkhvdGxpbmUiOm51bGwsIkNvbnRhY3RQaG9uZSI6bnVsbCwiU29ydENvZGVBbmRSb3V0ZVByaW9yaXR5IjoiMk1fMTMtQiIsIk9yZGluYWxOdW1iZXJPZlNvIjoiNDY5NDUxIiwiU29Jc0NhbmNlbGxlZCI6ZmFsc2UsIkNsaWVudFBpY2tVcEluZm8iOiIiLCJTaGlwcGluZ05vdGVGb3JDbGllbnRQaWNrVXAiOiIiLCJTaGlwcGluZ09yZGVyUGhvbmVPcmlnaW4iOiIwODU4MjgxMzI4IiwiU29ydENvZGUzUGwiOm51bGwsIlNob3dTb3J0Q29kZTNQbCI6ZmFsc2UsIlNob3dTb3J0Q29kZUFuZFJvdXRlUHJpb3JpdHkiOnRydWUsIlNob3dOb3RlIjpmYWxzZSwiQ2xpZW50Q29kZSI6Ik1TTiIsIkNsaWVudE5hbWUiOiJDw5RORyBUWSBUTkhIIE3hu7ggUEjhuqhNIE1FSVNIQU5HIFZJ4buGVCBOQU0iLCJIb3RsaW5lQ2xpZW50QnJhbmNoIjpudWxsLCJDbGllbnRCcmFuY2hDb2RlIjpudWxsLCJEZWxpdmVyeVN0YXRpb24iOm51bGx9XSwiRXh0cmFTZXJ2aWNlcyI6W10sIklzRGVhZGxpbmVTaGlwcGluZ1RlbXBsYXRlIjpmYWxzZSwiU29ydENvZGUiOiIyTV8xMy1CIiwiU2hpcHBpbmdTZXJ2aWNlQ29kZSI6IkVUT04gQkNTIiwiRGVsaXZlcnlEZWFkbGluZSI6IjI3LzAzLzIwMjUiLCJEZWxpdmVyeURlYWRsaW5lSG91ciI6IjEwOjAwIiwibGFuZ3VhZ2VzIjp7IlNoaXBwaW5nTGFiZWwiOiJNw6MgbmjDo24gduG6rW4gY2h1eeG7g24iLCJTT0NvZGUiOiJNw6MgU08iLCJOb3RlIjoiR2hpIGNow7oifSwiQ3VycmVudFRpbWUiOiIyNy8wMyAxNTowNCJ9LCJ1cmwiOiIiLCJwcmludFRlbXBsYXRlTWFwcGluZyI6eyJEb2N1bWVudFR5cGUiOiJTaGlwcGluZ0xhYmVsQjJDIiwiQ2xpZW50Q29kZSI6bnVsbCwiVGVtcGxhdGVDb2RlIjoiU2hpcHBpbmdMYWJlbEIyQ0E3IiwiT2JqZWN0VHlwZSI6IlNhbGVPcmRlciIsIlByaW50T3B0aW9ucyI6eyJzY2FsZSI6MSwicGFnZVNpemUiOiJBNyIsIm9yaWVudGF0aW9uIjoiTGFuZHNjYXBlIn0sIklzQWN0aXZlIjp0cnVlfX0="
  }
  req.body = body;
  await handlePrintRequest(req, res);
});

app.get('/get-chrome-path', (req, res) => {
  const chromePath = browserPage.getChromePath();
  res.json({ chromePath });
});

app.post("/print", async (req, res) => {
  await handlePrintRequest(req, res);
});

async function handlePrintRequest(req, res) {
  var body = req.body;
  var processKey = `${(body.printtrackingcode || "")}_${(await Ultils.makeid(5))}_${(new Date().getTime()) / 1}`; 
  try {
   
    
    console.log('printtrackingcode: ', body.printtrackingcode,
      'data: ', body.data,
      'fileUrl: ', body.fileUrl,
      'printer: ', body.printer,
      'printerpaper: ', body.printerpaper,
      'options: ', body.options,
      'os: ', body.os,
      'processKey: ', processKey
    );

    var config = Ultils.readFilePrinterConfig();
    if (body.data) {
      if (config["IsGenerateBase64ToPDFByDocmanService"]) {
        if (config["IsDownloadPdfByOtherService"]) {
          const result = await Ultils.generatePDFFileFromPDFUrl({ data: body.data, filename: processKey });
          if (result.fileUrl) {
            downloadFile({ url: result.fileUrl, options: result.options }, (path) => {
              execPrint(path, res, null, result.options.Paper, result.options, body.os, processKey)
            });
          }
        } else {
          const result = await Ultils.generatePDFFileFromHtmlUrl({ data: body.data, filename: processKey });
          if (result.fileUrl) {
            execPrint(result.fileUrl, res, null, result.options.Paper, result.options, body.os, processKey)
          }
        }
      }
      else {
        if (config["IsDownloadPdfByOtherService"]) {
          var result = await Ultils.generatePDFFileFromData({ data: body.data, fileName: processKey });
          if (result.fileUrl) {
            downloadFile({ url: result.fileUrl, options: result.options }, (path) => {
              execPrint(path, res, null, result.options.Paper, result.options, body.os, processKey)
            });
          }
        }
        else {
          var result = await Ultils.generatePDFFileFromDataByPrintLocal({ data: body.data, fileName: processKey });
          if (result.fileUrl) {
            execPrint(result.fileUrl, res, null, result.options.Paper, result.options, body.os, processKey)
          }
        }
      }
    }
    else {
      if (!body.fileUrl) {
        res.json({ status: "Error", message: "fileUrl or data is required" })
        logger.logError("fileUrl or data is required");
      }
      if (!body.printer && !body.printerpaper) {
        res.json({ status: "Error", message: "printer or printerpaper is required" })
        logger.logError("printer or printerpaper is required");
      }

      if (config["IsDownloadPdfByOtherService"]) {
        var result = await Ultils.generatePDFFileFromURL(body.fileUrl, body.options);
        if (result.fileUrl) {
          downloadFile({ url: result.fileUrl, options: result.options }, (path) => {
            execPrint(path, res, body.printer, body.printerpaper, body.options, body.os, processKey)
          });
        }
      }
      else {
        downloadFile({ url: body.fileUrl, options: body.options }, (path) => {
          execPrint(path, res, body.printer, body.printerpaper, body.options, body.os, processKey)
        });
      }
    }
  } catch (err) {
    const logMessage = `Error in handlePrintRequest  ${processKey}\n${err.message}\n${err.stack}`;
    console.log(logMessage);
    logger.logError(logMessage);
    res.json({ Status: "Error", message: logMessage});
  }
};


const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads");
  },
});
const upload = multer({ storage });

const downloadFile = ({ url, options, outputFileName }, callback) => {
  adapterFor(url).get(url, (downloadRes) => {
    url = url.trim().replace(/ /g, "%20");
    var extname = path.extname(url);
    if (extname == ".html") {
      var pdfName = (outputFileName ?? path.basename(url, ".html")) + '.pdf';
      const pathSave = './uploads/' + pdfName;

      parseHTMLToPDF(url, pathSave, options).then(e => {
        callback(pathSave);
        console.log('Download Complete');
      });
    } else if (extname == ".pdf") {
      var name = (outputFileName ?? path.basename(url, ".pdf")) + '.pdf';
      // var name = path.basename(url,".pdf") + '.pdf'
      const pathSave = './uploads/' + name;
      const filePath = fs.createWriteStream(pathSave);
      downloadRes.pipe(filePath);
      filePath.on('finish', () => {
        callback(pathSave)
        filePath.close();
        console.log('Download Complete')
      });
    }
  });
};

const execPrint = (filePath, res, printer, printerpaper, options, os, processKey) => {
  const printFn = (os && os.toUpperCase()) == OS_LINUX ? execPrintLinux : execPrintWindows;
  printFn(filePath, res, printer, printerpaper, options, processKey);
}

const execPrintWindows = (filePath, res, printer, printerpaper, options, processKey) => {
  var setting = Ultils.formatWindowsPrintSettings(options);
  var printername = printer || Ultils.getDefaultPrinter(printerpaper);

  if (!printername) {
    res.json({ Status: "Error", message: "printer has not been set up" });
    logger.logError("printer has not been set up");
  }
  var deviceInfo = actionGetDeviceInfo();
  const cmd = `SumatraPDF.exe -print-to "${printername}" -print-settings "${setting}" ${filePath}`;
  console.log(cmd)
  exec(cmd, (error, stdout, stderr) => {
    if (error) {
      console.log('Print Error:' + processKey);
      logger.logError(cmd + '.message: ' + error.message);
      res.json({ Status: "Error", message: error.message, DeviceInfo: deviceInfo });
      return;
    }
    console.log('Print Completed:' + processKey);
    res.json({ Status: "Success", message: `Command Success: ${cmd}`, DeviceInfo: deviceInfo });
  })
}

const execPrintLinux = (filePath, res, printer, printerpaper, options, processKey) => {
  var setting = Ultils.formatLinuxPrintSettings(options);
  var printername = printer || Ultils.getDefaultPrinter(printerpaper);
  if (!printername) {
    logger.logError("Printer has not been set up");
    res.json({ Status: "Error", message: "printer has not been set up" });
  }
  var deviceInfo = actionGetDeviceInfo();

  const cmd = `lp -d ${printername} -o "${setting}" -t "${processKey}" -H immediate -q 100 ${filePath}`;
  console.log(cmd)
  exec(cmd, (error, stdout, stderr) => {
    if (error) {
      console.log('Print Error:' + processKey);
      logger.logError(cmd + '.message: ' + error.message);
      res.json({ Status: "Error", message: error.message, DeviceInfo: deviceInfo });
      return;
    }
    console.log('Print Completed:' + processKey);
    res.json({ Status: "Success", message: `Command Success: ${cmd}`, DeviceInfo: deviceInfo });
  })
}

const parseHTMLToPDF = async (url, outpath, options) => {
  var param = { format: 'A6' };
  if (options && options['Paper']) {
    var config = Ultils.readFilePrinterConfig();
    if (config && config['PageSize']) {
      param = config['PageSize'][options['Paper']];
    }
  }
  if (options && (options['margin'] || options['Margin'])) {
    param['margin'] = options['margin'] || options['Margin'];
  }
  const { browser, page } = await browserPage.getBrowserPage();

  await page.goto(url, { waitUntil: 'networkidle2', timeout: 0 });
  page.on('console', (msg) => console.log(`PAGE LOG: ${msg.text()}`));
  page.on('pageerror', (err) => console.error('PAGE ERROR:', err));
  await page.pdf({
    path: outpath,
    printBackground: true, ...
    param
  });
  page.close().then(() => {
    console.log('browser#close()')
    browser.close();
  })
};

const getPrinterLists = async () => {
  return await getPrinters().then((result) => {
    return result;
  });
}

const actionGetDeviceInfo = () => {
  const computerName = os.hostname();
  const nets = networkInterfaces();
  const results = Object.create(null);
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      const familyV4Value = typeof net.family === 'string' ? 'IPv4' : 4
      if (net.family === familyV4Value && !net.internal) {
        if (!results[name]) {
          results[name] = [];
        }
        results[name].push(net.address);
      }
    }
  }
  return ({
    "ComputerName": computerName,
    "Networks": {
      ...results
    },
    "Version": Version,
    "OS": os.platform()
  });
};

app.use(logErrors)
// listener.listen(80).on('error', function(err) { });

app.listen(port, () => {
  console.log(`
    \nPrinter is running on url http://localhost:${port}
    \nPress CTL + C to stop Sprinter
  `)
})

