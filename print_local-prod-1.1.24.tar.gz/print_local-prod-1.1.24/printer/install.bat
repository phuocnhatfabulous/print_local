TIMEOUT 1
call npm install
call npm start

TIMEOUT 1
C: 
cd WINDOWS\system32>
net start PrintLocal.exe
