**Install turtorial**
1. Cài đặt thư viện:
    
    a. Backend: 
```
cd .\printer\ 
npm install
```

2. Cài đặt SumatraPDF: https://www.sumatrapdfreader.org/download-free-pdf-viewer

3. Thay đổi cài đặt trong C:\Users\username\AppData\Local\Temp\OVTeam\app.ini:

    a. Thay đổi PrinterLabel
    
    b. Thay đổi PrinterPaper

4. Thêm khẩu giấy trên máy in ở control panel

5. Chạy app: 
```
cd .\printer\
node index.js
```